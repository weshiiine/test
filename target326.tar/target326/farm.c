/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned getval_382()
{
    return 3284633928U;
}

void setval_397(unsigned *p)
{
    *p = 2425394264U;
}

void setval_133(unsigned *p)
{
    *p = 3281031256U;
}

unsigned addval_361(unsigned x)
{
    return x + 2425378902U;
}

void setval_364(unsigned *p)
{
    *p = 2428995912U;
}

void setval_446(unsigned *p)
{
    *p = 2425387172U;
}

unsigned addval_331(unsigned x)
{
    return x + 3284634056U;
}

unsigned addval_220(unsigned x)
{
    return x + 3267856712U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned addval_157(unsigned x)
{
    return x + 3317809545U;
}

unsigned addval_162(unsigned x)
{
    return x + 2430601544U;
}

void setval_256(unsigned *p)
{
    *p = 3221275017U;
}

unsigned addval_277(unsigned x)
{
    return x + 3767224476U;
}

unsigned getval_159()
{
    return 3675838089U;
}

unsigned addval_128(unsigned x)
{
    return x + 3372796425U;
}

unsigned addval_383(unsigned x)
{
    return x + 3677407881U;
}

unsigned getval_371()
{
    return 3353381192U;
}

unsigned addval_181(unsigned x)
{
    return x + 3286272328U;
}

unsigned addval_400(unsigned x)
{
    return x + 2747386505U;
}

void setval_101(unsigned *p)
{
    *p = 3767126230U;
}

unsigned getval_194()
{
    return 3525364361U;
}

unsigned getval_130()
{
    return 3676881289U;
}

unsigned addval_387(unsigned x)
{
    return x + 3524840073U;
}

unsigned getval_224()
{
    return 3524843145U;
}

unsigned addval_103(unsigned x)
{
    return x + 3281043721U;
}

void setval_469(unsigned *p)
{
    *p = 3286272456U;
}

unsigned addval_375(unsigned x)
{
    return x + 3281049241U;
}

unsigned addval_183(unsigned x)
{
    return x + 3223898761U;
}

unsigned getval_433()
{
    return 3224947337U;
}

unsigned addval_415(unsigned x)
{
    return x + 3372794241U;
}

unsigned getval_134()
{
    return 3224950409U;
}

unsigned addval_354(unsigned x)
{
    return x + 3229925769U;
}

unsigned addval_235(unsigned x)
{
    return x + 3247489417U;
}

void setval_378(unsigned *p)
{
    *p = 3223377417U;
}

unsigned getval_155()
{
    return 3766569176U;
}

void setval_191(unsigned *p)
{
    *p = 3232028297U;
}

unsigned addval_335(unsigned x)
{
    return x + 2425411209U;
}

void setval_436(unsigned *p)
{
    *p = 3531134601U;
}

unsigned getval_290()
{
    return 3531915657U;
}

unsigned addval_259(unsigned x)
{
    return x + 3247491721U;
}

unsigned getval_357()
{
    return 2430634312U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
